## Ne değişti? / What changed?

-

## Kontrol listesi / Checklist

- [ ] PHP syntax kontrolü yapıldı / PHP syntax checked
- [ ] README/docs gerekiyorsa güncellendi / README/docs updated if needed
- [ ] Credential, session ID veya token commit edilmedi / No credentials or tokens committed
- [ ] Değişiklik geriye dönük uyumluluğu dikkate alıyor / Backward compatibility considered
